package com.sbi.dashboard.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.dashboard.entity.Account;
import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {
	
	@Autowired
	AccountRepository accRepository;
	
	@Override
	public List<Account> getAllAccountsSingleCustomerService(int custId) {
		// TODO Auto-generated method stub
		System.out.println("Account Service is invoked.....");
		List<Account> acc ;
		acc = accRepository.getAllAccountsSingleCustomer(custId);
		
		return acc;
	}
	
	

}
