package com.sbi.dashboard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.service.CustomerService;



@CrossOrigin
@RestController
@RequestMapping("/profile")
public class CustomerController {
	
	@Autowired
	CustomerService custServ;
	
	@RequestMapping("/{custNo}")
	public Customer findSingleCust (@PathVariable("custNo") int cNo) {
		
		System.out.println("DepartmentController: findSingleDept(int) is invoked...."+cNo);
		Customer customer;
		customer = custServ.getCustomerByIdService(cNo);
		 
		return customer;		
	}
}
