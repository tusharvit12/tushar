package com.sbi.dashboard.repository;

import org.springframework.stereotype.Repository;

import com.sbi.dashboard.entity.Account;
import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.entity.Transaction;

@Repository
public interface TransactionRepository {
	
	void fundTransfer(Transaction newTxn, int sAcc, int dAcc, int txnAmt);

}
