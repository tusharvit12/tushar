package com.sbi.dashboard;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.dashboard.controller.AccountController;
import com.sbi.dashboard.entity.Account;
import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.repository.AccountRepository;
import com.sbi.dashboard.repository.CustomerRepository;
import com.sbi.dashboard.repository.TransactionRepository;
import com.sbi.dashboard.service.AccountService;

@SpringBootTest
class MyDashboardProjectApplicationTests {

	@Autowired
	TransactionRepository txnRepo;
	
	@Test
	public void testFundTransfer() {
		
		System.out.println("INSIDE TEST CLASS");
		txnRepo.fundTransfer(null, 314763, 314764, 3500);
		
	}
	
	
	@Autowired
	CustomerRepository custRepo;
	
	@Test
	void testCustomer() {
		
		Customer cust = custRepo.getCustomerById(105);
		System.out.println("cust "+cust.getCustEmail());
	
	}
	
	@Test
	public void testGetCustomerById() {
		Customer cust = custRepo.getCustomerById(105);
		System.out.println("CUstomer NAME is:    "+cust.getCustName());
	}
	
	@Test
	public void testGetCustomerByIdService() {
		Customer cust = custRepo.getCustomerById(105);
		System.out.println("CUstomer MOBILE is:    "+cust.getCustMobile());
	}
	
	@Test
	public void testFindSingleCustCtrl() {
		Customer cust = custRepo.getCustomerById(105);
		System.out.println("CUstomer PAN is:    "+cust.getCustPan());
	}
	
	
	
	
	@Autowired
	AccountRepository accRepoTest;
	
	@Test
	public void testAccountforSingleCustomerRepository() {
		List<Account> accTest=accRepoTest.getAllAccountsSingleCustomer(1015);
		
		for(Account accPrint:accTest) {
			System.out.println("Printing Acc Number:"+accPrint.getAccNumber());
			System.out.println("Printint Acc Type:"+accPrint.getAccType());
			System.out.println("Printing Acc Balance:"+accPrint.getAccBalance());
			
		}

	}
	
	@Autowired
	AccountService accServTest;
	
	@Test
	public void testAccountforSingleCustomerService() {
		List<Account> accTest=accServTest.getAllAccountsSingleCustomerService(105);
		
		for(Account accPrint:accTest) {
			System.out.println("Printing Acc Number:"+accPrint.getAccNumber());
			System.out.println("Printint Acc Type:"+accPrint.getAccType());
			System.out.println("Printing Acc Balance:"+accPrint.getAccBalance());
			
		}
	}
	
	
	@Autowired
	AccountController accCtrlTest;
	
	@Test
	public void testAccountforSingleCustomerCtrl() {
		List<Account> accTest=accCtrlTest.findAccountforSingleCustomer(1015);
		
		for(Account accPrint:accTest) {
			System.out.println("Printing Acc Number:"+accPrint.getAccNumber());
			System.out.println("Printint Acc Type:"+accPrint.getAccType());
			System.out.println("Printing Acc Balance:"+accPrint.getAccBalance());
			
		}
	}
	

}
