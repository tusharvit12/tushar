package com.sbi.dashboard.service;

import org.springframework.stereotype.Service;

import com.sbi.dashboard.entity.Customer;

@Service
public interface CustomerService {
	
	Customer getCustomerByIdService(int custNo);

}
