package com.sbi.dashboard.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.sbi.dashboard.exception.AccountNotFoundException;

public class AccountNotFoundAdvice {
	
	public class DepartmentNotFoundAdvice {

		@ResponseBody
		@ExceptionHandler (AccountNotFoundException.class)
		@ResponseStatus(HttpStatus.NOT_FOUND)
		String departmentNotFoundhandler(AccountNotFoundException ex)
		{
			System.out.println("account Not Found handler.....");
			return ex.getMessage() + "its not there, means 404";
		
		}
	}

}
