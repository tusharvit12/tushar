
package com.sbi.dashboard.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository custRepository;
	
	@Override
	public Customer getCustomerByIdService(int custNo) {
		// TODO Auto-generated method stub
		System.out.println("Customer Service is invoked.....");
		Customer cust ;
		cust = custRepository.getCustomerById(custNo);
		System.out.println("Customer Name is:"+cust.getCustName());
		return cust;
	}

}
