package com.sbi.dashboard.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonManagedReference;



@Component
@Entity
@Table(name="customer_dashboard")
public class Customer {
	
	@Id
	@Column(name="CUST_ID")
	private int custId;                    //                NOT NULL NUMBER
	
	@Column(name="NAME")
	private String custName;               //                NOT NULL VARCHAR2(50)
	
	@Column(name="EMAIL")
	private String custEmail;              //                NOT NULL VARCHAR2(50)
	
	@Column(name="MOBILE")
	private String custMobile;                //                NOT NULL NUMBER
	
	@Column(name="DATE_OF_BIRTH")
	private Date custDob;                  //                NOT NULL DATE
	
	@Column(name="PAN_NUMBER")
	private String custPan;                //                NOT NULL VARCHAR2(10)
	
	@Column(name="ADDRESS_ID")
	private int custAddId;                 //                NOT NULL NUMBER
	
	@OneToMany(mappedBy="customer", fetch = FetchType.EAGER, cascade = CascadeType.ALL )
	private List<Account> acountList;

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public String getCustMobile() {
		return custMobile;
	}

	public void setCustMobile(String custMobile) {
		this.custMobile = custMobile;
	}

	public Date getCustDob() {
		return custDob;
	}

	public void setCustDob(Date custDob) {
		this.custDob = custDob;
	}

	public String getCustPan() {
		return custPan;
	}

	public void setCustPan(String custPan) {
		this.custPan = custPan;
	}

	public int getCustAddId() {
		return custAddId;
	}

	public void setCustAddId(int custAddId) {
		this.custAddId = custAddId;
	}

	 @JsonManagedReference
	public List<Account> getAcountList() {
		return acountList;
	}

	public void setAcountList(List<Account> acountList) {
		this.acountList = acountList;
	}

	

	
	
}
