package com.sbi.dashboard.repository;

import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.sbi.dashboard.entity.Customer;

@Repository
public class CustomerRepositoryImpl implements CustomerRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	public CustomerRepositoryImpl() {
		System.out.println("DepartmentRepositoryImpl()....");
	}
	
	@Override
	
	
	
	
	public Customer getCustomerById(int id) {
		Customer cust=null;
		System.out.println("CustomerRepository is invoked....." +id);
		try {
			cust = entityManager.find(Customer.class, id);
			System.out.println("Customer NAME IS"+cust.getCustName());
		}catch (Exception se) {
			se.printStackTrace();
		}
		return cust;
		
	}

}
