package com.sbi.dashboard;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.dashboard.controller.AccountController;
import com.sbi.dashboard.entity.Account;
import com.sbi.dashboard.entity.Customer;
import com.sbi.dashboard.repository.AccountRepository;
import com.sbi.dashboard.repository.CustomerRepository;
import com.sbi.dashboard.service.AccountService;

@SpringBootTest
class MyDashboardProjectApplicationTests {

	
	@Autowired
	CustomerRepository custRepo;
	
	@Test
	void testCustomer() {
		
		Customer cust = custRepo.getCustomerById(1015);
		System.out.println("cust "+cust.getCustEmail());
	
	}
	
	@Autowired
	AccountRepository accRepoTest;
	
	@Test
	public void testAccountforSingleCustomerRepository() {
		List<Account> accTest=accRepoTest.getAllAccountsSingleCustomer(1015);
		
		for(Account accPrint:accTest) {
			System.out.println("Printing Acc Number:"+accPrint.getAccNumber());
			System.out.println("Printint Acc Type:"+accPrint.getAccType());
			System.out.println("Printing Acc Balance:"+accPrint.getAccBalance());
			
		}

	}
	
	@Autowired
	AccountService accServTest;
	
	@Test
	public void testAccountforSingleCustomerService() {
		List<Account> accTest=accServTest.getAllAccountsSingleCustomerService(1015);
		
		for(Account accPrint:accTest) {
			System.out.println("Printing Acc Number:"+accPrint.getAccNumber());
			System.out.println("Printint Acc Type:"+accPrint.getAccType());
			System.out.println("Printing Acc Balance:"+accPrint.getAccBalance());
			
		}
	}
	
	
	@Autowired
	AccountController accCtrlTest;
	
	@Test
	public void testAccountforSingleCustomerCtrl() {
		List<Account> accTest=accCtrlTest.findAccountforSingleCustomer(1015);
		
		for(Account accPrint:accTest) {
			System.out.println("Printing Acc Number:"+accPrint.getAccNumber());
			System.out.println("Printint Acc Type:"+accPrint.getAccType());
			System.out.println("Printing Acc Balance:"+accPrint.getAccBalance());
			
		}
	}
	

}
